Config = {}

Config.Consumables = {
    -- JOINTS (Fast-acting, short duration)
    ['your_item'] = {
        category = 'joint',
        duration = 45000,
        armor = {add = 15, cap = 100},
        speedMultiplier = 1.15,
        screenEffect = "DrugsMichaelAliensFight",
        anim = 'smoke',
        label = "Smoking Joint",
        cooldown = 30
    },
    ['your_item'] = {
        category = 'joint',
        duration = 45000,
        armor = {add = 20, cap = 100},
        screenEffect = "DrugsTrevorClownsFight",
        anim = 'smoke',
        label = "Smoking Joint",
        cooldown = 30
    },
    ['your_item'] = {
        category = 'joint',
        duration = 45000,
        speedMultiplier = 1.2,
        staminaBoost = true,
        screenEffect = "DrugsDrivingIn",
        anim = 'smoke',
        label = "Smoking Joint",
        cooldown = 30
    },
    ['your_item'] = {
        category = 'joint',
        duration = 45000,
        armor = {add = 18, cap = 100},
        healthRegen = true,
        screenEffect = "MenuMGSelectionTint",
        anim = 'smoke',
        label = "Smoking Joint",
        cooldown = 30
    },

    -- GUMMIES (Medium duration)
    ['your_item'] = {
        category = 'edible',
        duration = 75000,
        armor = {add = 40, cap = 100},
        speedMultiplier = 1.1,
        screenEffect = "DrugsMichaelAliensFight",
        anim = 'eat',
        label = "Eating Gummies",
        cooldown = 30
    },
    ['your_item'] = {
        category = 'edible',
        duration = 75000,
        armor = {add = 50, cap = 100},
        healthRegen = true,
        screenEffect = "DrugsTrevorClownsFight",
        anim = 'eat',
        label = "Eating Gummies",
        cooldown = 30
    },
    ['your_item'] = {
        category = 'edible',
        duration = 75000,
        speedMultiplier = 1.2,
        staminaBoost = true,
        screenEffect = "DrugsDrivingIn",
        anim = 'eat',
        label = "Eating Gummies",
        cooldown = 30
    },
    ['your_item'] = {
        category = 'edible',
        duration = 75000,
        healthRegen = true,
        armor = {add = 30, cap = 100},
        screenEffect = "MenuMGSelectionTint",
        anim = 'eat',
        label = "Eating Gummies",
        cooldown = 30
    },

    -- TEA (Long duration, utility-focused)
    ['your_item'] = {
        category = 'drink',
        duration = 70000,
        staminaBoost = true,
        screenEffect = "MenuMGSelectionTint",
        anim = 'drink',
        label = "Drinking Tea",
        cooldown = 30
    },
    ['your_item'] = {
        category = 'drink',
        duration = 70000,
        armor = {add = 25, cap = 100},
        screenEffect = "DrugsDrivingIn",
        anim = 'drink',
        label = "Drinking Tea",
        cooldown = 30
    },
    ['your_item'] = {
        category = 'drink',
        duration = 70000,
        speedMultiplier = 1.15,
        staminaBoost = true,
        screenEffect = "DrugsDrivingOut",
        anim = 'drink',
        label = "Drinking Tea",
        cooldown = 30
    },
    ['your_item'] = {
        category = 'drink',
        duration = 70000,
        healthRegen = true,
        armor = {add = 20, cap = 100},
        screenEffect = "MenuMGSelectionTint",
        anim = 'drink',
        label = "Drinking Tea",
        cooldown = 30
    },

    -- COOKIES (Balanced duration, mixed effects)
    ['your_item'] = {
        category = 'baked',
        duration = 65000,
        armor = {add = 30, cap = 100},
        speedMultiplier = 1.1,
        screenEffect = "DrugsMichaelAliensFight",
        anim = 'eat',
        label = "Eating Cookie",
        cooldown = 30
    },
    ['your_item'] = {
        category = 'baked',
        duration = 65000,
        armor = {add = 35, cap = 100},
        screenEffect = "DrugsTrevorClownsFight",
        anim = 'eat',
        label = "Eating Cookie",
        cooldown = 30
    },
    ['your_item'] = {
        category = 'baked',
        duration = 65000,
        speedMultiplier = 1.2,
        staminaBoost = true,
        screenEffect = "DrugsDrivingIn",
        anim = 'eat',
        label = "Eating Cookie",
        cooldown = 30
    },
    ['your_item'] = {
        category = 'baked',
        duration = 65000,
        healthRegen = true,
        armor = {add = 25, cap = 100},
        screenEffect = "MenuMGSelectionTint",
        anim = 'eat',
        label = "Eating Cookie",
        cooldown = 30
    }
}

-- Animation dictionaries
Config.Animations = {
    smoke = {
        dict = 'amb@world_human_smoking@male@male_a@base',
        anim = 'base',
        flag = 49,
        prop = {
            model = 'prop_cs_ciggy_01',
            bone = 28422,
            pos = {0.0, 0.0, 0.0},
            rot = {0.0, 0.0, 0.0}
        }
    },
    eat = {
        dict = 'mp_player_inteat@burger',
        anim = 'mp_player_int_eat_burger',
        flag = 49
    },
    drink = {
        dict = 'amb@world_human_drinking@beer@male@idle_a',
        anim = 'idle_a',
        flag = 49,
        prop = {
            model = 'prop_amb_beer_bottle',
            bone = 28422,
            pos = {0.0, 0.0, 0.0},
            rot = {0.0, 0.0, 0.0}
        }
    }
}

