local QBCore = exports['qb-core']:GetCoreObject() -- replace with your Get Core Object Export
local activeEffects = {}
local cooldowns = {}
local isConsuming = false

-- Thread tracking for cleanup
local ActiveThreads = {
    healthRegen = nil,
    screenEffect = nil,
    durationTimer = nil
}

-- Caching system
local Cache = {
    consumables = {},           -- Cached consumable data
    animDicts = {},             -- Cached loaded animation dictionaries
    propModels = {},            -- Cached loaded prop models
    animData = {},              -- Cached animation data
    ped = nil,                  -- Cached player ped
    pedUpdateTime = 0           -- Last ped update time
}

-- Screen effect names mapping
local ScreenEffects = {
    ["DrugsMichaelAliensFight"] = "DrugsMichaelAliensFight",
    ["DrugsTrevorClownsFight"] = "DrugsTrevorClownsFight",
    ["DrugsDrivingIn"] = "DrugsDrivingIn",
    ["DrugsDrivingOut"] = "DrugsDrivingOut",
    ["MenuMGSelectionTint"] = "MenuMGSelectionTint"
}

-- Initialize cache with all consumables from config
CreateThread(function()
    local count = 0
    for itemName, consumableData in pairs(Config.Consumables) do
        Cache.consumables[itemName] = consumableData
        count = count + 1
    end
    print("^2[Consumables] Cached " .. count .. " consumables^0")
end)

-- Get cached player ped (updates every 500ms)
local function GetCachedPed()
    local currentTime = GetGameTimer()
    if not Cache.ped or (currentTime - Cache.pedUpdateTime) > 500 then
        Cache.ped = PlayerPedId()
        Cache.pedUpdateTime = currentTime
    end
    return Cache.ped
end

-- Get consumable data with caching
local function GetConsumableDataCached(itemName)
    if Cache.consumables[itemName] then
        return Cache.consumables[itemName]
    end
    -- Fallback to config if not in cache (for dynamically registered items)
    local data = Config.Consumables[itemName]
    if data then
        Cache.consumables[itemName] = data
    end
    return data
end

-- Register a consumable item (Export function)
function RegisterConsumable(itemName, consumableData)
    if not itemName or not consumableData then
        print("^1[Consumables] Error: Invalid item name or data^0")
        return false
    end
    
    Config.Consumables[itemName] = consumableData
    Cache.consumables[itemName] = consumableData -- Update cache
    print("^2[Consumables] Registered consumable: " .. itemName .. "^0")
    return true
end

-- Get consumable data (Export function)
function GetConsumableData(itemName)
    return GetConsumableDataCached(itemName)
end

-- Check if item is consumable (Export function)
function IsConsumable(itemName)
    return GetConsumableDataCached(itemName) ~= nil
end

-- Load animation dictionary with caching
local function LoadAnimDict(dict)
    if Cache.animDicts[dict] then
        return true -- Already loaded
    end
    
    RequestAnimDict(dict)
    local timeout = 0
    while not HasAnimDictLoaded(dict) and timeout < 100 do
        Wait(10)
        timeout = timeout + 1
    end
    
    if HasAnimDictLoaded(dict) then
        Cache.animDicts[dict] = true
        return true
    end
    return false
end

-- Load prop model with caching
local function LoadPropModel(modelName)
    local modelHash = GetHashKey(modelName)
    if Cache.propModels[modelHash] then
        return modelHash -- Already loaded
    end
    
    RequestModel(modelHash)
    local timeout = 0
    while not HasModelLoaded(modelHash) and timeout < 100 do
        Wait(10)
        timeout = timeout + 1
    end
    
    if HasModelLoaded(modelHash) then
        Cache.propModels[modelHash] = true
        return modelHash
    end
    return nil
end

-- Get animation data with caching
local function GetAnimData(animType)
    if Cache.animData[animType] then
        return Cache.animData[animType]
    end
    
    local data = Config.Animations[animType]
    if data then
        Cache.animData[animType] = data
    end
    return data
end

-- Play animation based on type with progress circle
-- animationDuration: how long the animation/progress takes (shorter)
function PlayConsumableAnimation(animType, animationDuration, label)
    local animData = GetAnimData(animType)
    if not animData then return false end

    if not LoadAnimDict(animData.dict) then
        print("^1[Consumables] Failed to load animation dictionary: " .. animData.dict .. "^0")
        return false
    end

    local ped = GetCachedPed()
    
    -- Handle prop if exists (setup before progress)
    local propModel = nil
    local prop = nil
    if animData.prop then
        propModel = LoadPropModel(animData.prop.model)
        if not propModel then
            print("^1[Consumables] Failed to load prop model: " .. animData.prop.model .. "^0")
            return false
        end
        
        prop = CreateObject(propModel, 0.0, 0.0, 0.0, true, true, true)
        if not DoesEntityExist(prop) then
            print("^1[Consumables] Failed to create prop^0")
            return false
        end
        
        AttachEntityToEntity(prop, ped, GetPedBoneIndex(ped, animData.prop.bone), 
            animData.prop.pos[1], animData.prop.pos[2], animData.prop.pos[3],
            animData.prop.rot[1], animData.prop.rot[2], animData.prop.rot[3], true, true, false, true, 1, true)
    end
    
    -- Start animation
    TaskPlayAnim(ped, animData.dict, animData.anim, 8.0, -8.0, animationDuration, animData.flag, 0, false, false, false)
    
    -- Show progress circle (runs simultaneously with animation)
    local progressSuccess = lib.progressCircle({
        duration = animationDuration,
        position = 'bottom',
        label = label or 'Using item...',
        useWhileDead = false,
        canCancel = false,
        disable = {
            car = false,
            move = false,
            combat = true
        }
    })
    
    -- Wait for animation to complete
    Wait(animationDuration)
    
    -- Cleanup prop
    if prop and DoesEntityExist(prop) then
        DetachEntity(prop, true, true)
        DeleteObject(prop)
    end
    
    ClearPedTasks(ped)
    return progressSuccess
end

-- Apply armor effect
function ApplyArmorEffect(add, cap)
    local ped = GetCachedPed()
    local currentArmor = GetPedArmour(ped)
    local newArmor = math.min(currentArmor + add, cap)
    SetPedArmour(ped, newArmor)
end

-- Apply speed multiplier
function ApplySpeedMultiplier(multiplier)
    SetRunSprintMultiplierForPlayer(PlayerId(), multiplier)
    SetSwimMultiplierForPlayer(PlayerId(), multiplier)
end

-- Remove speed multiplier
function RemoveSpeedMultiplier()
    SetRunSprintMultiplierForPlayer(PlayerId(), 1.0)
    SetSwimMultiplierForPlayer(PlayerId(), 1.0)
end

-- Apply stamina boost
function ApplyStaminaBoost()
    local ped = PlayerPedId()
    SetPlayerSprint(PlayerId(), true)
    RestorePlayerStamina(PlayerId(), 100.0)
end

-- Health regeneration loop
function StartHealthRegen()
    -- Stop existing thread if any
    if ActiveThreads.healthRegen then
        activeEffects.healthRegen = false
    end
    
    activeEffects.healthRegen = true
    ActiveThreads.healthRegen = CreateThread(function()
        while activeEffects.healthRegen do
            Wait(1000)
            local ped = GetCachedPed()
            if not ped or ped == 0 then
                break -- Ped invalid, exit thread
            end
            local health = GetEntityHealth(ped)
            local maxHealth = GetEntityMaxHealth(ped)
            
            if health < maxHealth then
                SetEntityHealth(ped, math.min(health + 1, maxHealth))
            end
        end
        ActiveThreads.healthRegen = nil
    end)
end

-- Apply screen effect
function ApplyScreenEffect(effectName, duration)
    if not ScreenEffects[effectName] then return end
    
    -- Stop existing screen effect thread if any
    if ActiveThreads.screenEffect then
        -- Clear the effect name so the thread exits
        local oldEffect = activeEffects.screenEffect
        if oldEffect then
            AnimpostfxStop(oldEffect)
        end
        activeEffects.screenEffect = nil
        Wait(50) -- Give thread time to exit
    end
    
    activeEffects.screenEffect = effectName
    ActiveThreads.screenEffect = CreateThread(function()
        local endTime = GetGameTimer() + duration
        
        -- Start the effect (third param true = looped effect)
        AnimpostfxPlay(effectName, 0, true)
        
        -- Keep effect active until duration expires or effect is manually cleared
        while activeEffects.screenEffect == effectName and GetGameTimer() < endTime do
            Wait(0) -- Check every frame
        end
        
        -- Stop effect when loop exits
        AnimpostfxStop(effectName)
        if activeEffects.screenEffect == effectName then
            activeEffects.screenEffect = nil
        end
        ActiveThreads.screenEffect = nil
    end)
end

-- Remove all active effects
function RemoveAllEffects()
    if activeEffects.speedMultiplier then
        RemoveSpeedMultiplier()
        activeEffects.speedMultiplier = nil
    end
    
    -- Stop screen effect before clearing (so the thread can detect the change)
    if activeEffects.screenEffect then
        local currentEffect = activeEffects.screenEffect
        activeEffects.screenEffect = nil -- Clear first so thread exits
        AnimpostfxStop(currentEffect) -- Stop the effect
    end
    
    activeEffects.healthRegen = false
    activeEffects.staminaBoost = false
end

-- Cleanup expired cooldowns (runs periodically)
CreateThread(function()
    while true do
        Wait(60000) -- Check every minute
        local currentTime = GetGameTimer()
        for itemName, cooldownTime in pairs(cooldowns) do
            if cooldownTime <= currentTime then
                cooldowns[itemName] = nil -- Remove expired cooldown
            end
        end
    end
end)

-- Main consumable use function
-- Can be called with itemName (string) or itemData (table with 'name' field)
function UseConsumable(itemNameOrData, source)
    if isConsuming then
        QBCore.Functions.Notify("You are already consuming something!", "error")
        return false
    end

    -- Handle both string (itemName) and table (itemData) inputs
    local itemName = type(itemNameOrData) == "table" and (itemNameOrData.name or itemNameOrData.item) or itemNameOrData
    
    if not itemName then
        print("^1[Consumables] Error: Invalid item name^0")
        return false
    end

    local consumable = GetConsumableDataCached(itemName)
    if not consumable then
        print("^1[Consumables] Item not found in config: " .. tostring(itemName) .. "^0")
        return false
    end

    -- Check cooldown
    local playerId = GetPlayerServerId(PlayerId())
    if cooldowns[itemName] and cooldowns[itemName] > GetGameTimer() then
        local remaining = math.ceil((cooldowns[itemName] - GetGameTimer()) / 1000)
        QBCore.Functions.Notify("Cooldown: " .. remaining .. " seconds remaining", "error")
        return false
    end

    isConsuming = true
    
    -- Animation duration (shorter, e.g., 3-5 seconds)
    -- Joints get double duration (6 seconds), others get 3 seconds
    local animationDuration = (consumable.category == 'joint') and 6000 or 3000
    
    -- Play animation with progress circle
    local animationSuccess = PlayConsumableAnimation(consumable.anim, animationDuration, consumable.label)
    
    if not animationSuccess then
        isConsuming = false
        return false
    end
    
    -- Apply effects AFTER animation/progress completes
    if consumable.armor then
        ApplyArmorEffect(consumable.armor.add, consumable.armor.cap)
    end
    
    if consumable.speedMultiplier then
        activeEffects.speedMultiplier = consumable.speedMultiplier
        ApplySpeedMultiplier(consumable.speedMultiplier)
    end
    
    if consumable.staminaBoost then
        activeEffects.staminaBoost = true
        ApplyStaminaBoost()
    end
    
    if consumable.healthRegen then
        activeEffects.healthRegen = true
        StartHealthRegen()
    end
    
    -- Start screen effect AFTER animation completes (full duration from config)
    if consumable.screenEffect then
        activeEffects.screenEffect = consumable.screenEffect
        ApplyScreenEffect(consumable.screenEffect, consumable.duration)
    end
    
    -- Set cooldown
    if consumable.cooldown then
        cooldowns[itemName] = GetGameTimer() + (consumable.cooldown * 1000)
    end
    
    -- Remove effects after duration
    if ActiveThreads.durationTimer then
        -- Cancel previous duration timer if exists (shouldn't happen, but safety)
    end
    
    ActiveThreads.durationTimer = CreateThread(function()
        Wait(consumable.duration)
        RemoveAllEffects()
        QBCore.Functions.Notify("Effects have worn off", "info")
        ActiveThreads.durationTimer = nil
    end)
    
    isConsuming = false
    return true
end

-- Export functions
-- Note: Export prefix is determined by resource folder name
-- If folder is 'poseidon_consumables', use: exports['poseidon_consumables']:useConsumable()
exports('RegisterConsumable', RegisterConsumable)
exports('GetConsumableData', GetConsumableData)
exports('IsConsumable', IsConsumable)
exports('useConsumable', UseConsumable) -- Main export for inventory systems
exports('UseConsumable', UseConsumable) -- Keep uppercase for backwards compatibility

-- Event handler for item use (if your inventory system uses events)
RegisterNetEvent('consumables:useItem', function(itemName)
    UseConsumable(itemName)
end)

-- Cleanup function
local function FullCleanup()
    -- Stop all active effects
    RemoveAllEffects()
    
    -- Stop all active threads by clearing their conditions
    activeEffects.healthRegen = false
    activeEffects.screenEffect = nil
    activeEffects.staminaBoost = false
    
    -- Wait a bit for threads to exit
    Wait(100)
    
    -- Unload all animation dictionaries
    for dict, _ in pairs(Cache.animDicts) do
        if HasAnimDictLoaded(dict) then
            RemoveAnimDict(dict)
        end
    end
    
    -- Unload all prop models
    for modelHash, _ in pairs(Cache.propModels) do
        if HasModelLoaded(modelHash) then
            SetModelAsNoLongerNeeded(modelHash)
        end
    end
    
    -- Stop all screen effects (safety measure)
    for effectName, _ in pairs(ScreenEffects) do
        AnimpostfxStop(effectName)
    end
    
    -- Clear all caches
    Cache.consumables = {}
    Cache.animDicts = {}
    Cache.propModels = {}
    Cache.animData = {}
    Cache.ped = nil
    
    -- Clear cooldowns
    cooldowns = {}
    
    -- Clear active threads reference
    ActiveThreads = {
        healthRegen = nil,
        screenEffect = nil,
        durationTimer = nil
    }
    
    -- Reset state
    isConsuming = false
    activeEffects = {}
end

-- Cleanup on resource stop
AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() == resourceName then
        FullCleanup()
    end
end)

-- Cleanup on player disconnect (if using disconnect event)
AddEventHandler('QBCore:Client:OnPlayerUnload', function()
    FullCleanup()
end)

-- Cleanup on player logout
RegisterNetEvent('QBCore:Client:OnPlayerLogout', function()
    FullCleanup()
end)

