local QBCore = exports['qb-core']:GetCoreObject()

-- Server-side validation for consumable use
RegisterNetEvent('consumables:server:useItem', function(itemName)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then return end
    
    -- Check if item exists in player's inventory
    local hasItem = Player.Functions.GetItemByName(itemName)
    if not hasItem then
        TriggerClientEvent('QBCore:Notify', src, "You don't have this item!", "error")
        return
    end
    
    -- Check if item is consumable
    if not Config.Consumables[itemName] then
        TriggerClientEvent('QBCore:Notify', src, "This item is not consumable!", "error")
        return
    end
    
    -- Remove item from inventory
    Player.Functions.RemoveItem(itemName, 1)
    TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items[itemName], "remove", 1)
    
    -- Trigger client-side consumption
    TriggerClientEvent('consumables:useItem', src, itemName)
end)

-- Export function to register consumable from server
function RegisterConsumable(itemName, consumableData)
    if not itemName or not consumableData then
        print("^1[Consumables] Error: Invalid item name or data^0")
        return false
    end
    
    Config.Consumables[itemName] = consumableData
    print("^2[Consumables] Registered consumable: " .. itemName .. "^0")
    return true
end

exports('RegisterConsumable', RegisterConsumable)

